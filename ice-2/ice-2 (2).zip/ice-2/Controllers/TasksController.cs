﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using WebApplication15.Data;
using WebApplication15.Models;

namespace WebApplication15.Controllers
{
    public class TasksController : Controller
    {
        private readonly AppDbContext _db;
        public TasksController(AppDbContext context)
        {

            _db = context;

        }
        //get:tasks
        [HttpGet]
        public IActionResult Index(int projectId)
        {
            var tasks = _db.ProjectTasks.Where(t => t.ProjectId == projectId).ToList();
            ViewBag.ProjectId = projectId; //store projectid in viewbag
            return View(tasks);
        }
        //get:tasks/details
        [HttpGet]
        public IActionResult Details(int Id)
        {
            var task = _db.ProjectTasks.Include(t => t.Project) //include related project data
                                     .FirstOrDefault(t => t.ProjectTaskId == Id);
            if (task == null)
            {
                return NotFound();
            }
            return View(task);
        }
        [HttpGet]
        public IActionResult Create(int ProjectId)
        {
            var project = _db.Projects.Find(ProjectId);
            if (project == null)
            {
                return NotFound();
            }
            var task = new ProjectTask { ProjectId = ProjectId };
            return View(task);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Title", "Description", "ProjectId")] ProjectTask task)
        {
            if (ModelState.IsValid)
            {
                _db.ProjectTasks.Add(task);
                _db.SaveChanges();
                //redirect to index action with project id of created task 
                return RedirectToAction(nameof(Index), new { ProjectId = task.ProjectId });
            }
            //repulanate the project selectlist if returning to form 
            ViewBag.Projects = new SelectList(_db.Projects, "projectId", "Name", task.ProjectId);
            return View(task);
        }
        [HttpGet]
        public ActionResult Edit(int Id)
        {
            var task = _db.ProjectTasks.Include(t => t.Project)
                .FirstOrDefault(task => task.ProjectTaskId == Id);
            if (task == null) { return NotFound(); }
            ViewBag.Projects = new SelectList(_db.Projects, "ProjectId", "Name", task.ProjectId);
            return View(task);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("ProjectTaskId", "Title", "Description", "ProjectId")] ProjectTask task)
        {
            if (id != task.ProjectTaskId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _db.ProjectTasks.Update(task);
                _db.SaveChanges();
                return RedirectToAction(nameof(Index), new { projectId = task.ProjectId });
            }
            ViewBag.Projects = new SelectList(_db.Projects, "ProjectId", "Name", task.ProjectId);
            return View(task);

        }
        [HttpGet]
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var task = _db.ProjectTasks.Include(t => t.Project)
                .FirstOrDefault(t => t.ProjectTaskId == id);

            if (task == null)
            {
                return NotFound();
            }

            return View(task);
        }
        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int ProjectTaskId)
        {
            var task = _db.ProjectTasks.Find(ProjectTaskId);

            if (task == null)
            {
                return NotFound();
            }

            _db.ProjectTasks.Remove(task);
            _db.SaveChanges();

            return RedirectToAction(nameof(Index), new { projectId = task.ProjectId });
        }
    }
}


