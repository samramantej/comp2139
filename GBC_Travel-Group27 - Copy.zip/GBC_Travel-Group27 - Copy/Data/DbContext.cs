﻿using Microsoft.EntityFrameworkCore;
using GBC_Travel_Group27.Models;

namespace GBC_Travel_Group27.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<Flight> Flights { get; set; }
        public DbSet<Hotel> Hotels { get; set; }
        public DbSet<CarRental> CarRentals { get; set; }
        public DbSet<Booking> Bookings { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<Flight>()
                .Property(f => f.Price)
                .HasColumnType("decimal(18, 2)");

            modelBuilder.Entity<Hotel>()
                .Property(h => h.PricePerNight)
                .HasColumnType("decimal(18, 2)");

            modelBuilder.Entity<CarRental>()
                .Property(c => c.DailyRate)
                .HasColumnType("decimal(18, 2)");

            
            modelBuilder.Entity<Hotel>()
                .Property(h => h.Rating)
                .HasColumnName("Rating");

            
        }

    }
}
