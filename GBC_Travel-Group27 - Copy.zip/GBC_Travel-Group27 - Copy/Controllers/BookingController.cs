﻿using Microsoft.AspNetCore.Mvc;
using GBC_Travel_Group27.Data;
using GBC_Travel_Group27.Models;
using System;
using System.Linq;

namespace GBC_Travel_Group27.Controllers
{
    public class BookingController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookingController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult Create(Booking booking)
        {
            if (ModelState.IsValid)
            {
                // Populate booking properties from the form submission
                booking.BookingDate = DateTime.Now;

                _context.Bookings.Add(booking);
                _context.SaveChanges();

                // Redirect to a confirmation page
                return RedirectToAction("Confirmation", new { bookingId = booking.Id });
            }

            // If ModelState is not valid, return to the booking page with validation errors
            return View(booking);
        }


        public IActionResult Confirmation(int bookingId)
        {
            var booking = _context.Bookings.FirstOrDefault(b => b.Id == bookingId);
            if (booking == null)
            {
                return RedirectToAction("Book");
            }
            return View(booking);
        }
    }
}


