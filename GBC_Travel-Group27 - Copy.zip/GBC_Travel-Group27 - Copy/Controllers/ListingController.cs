﻿using GBC_Travel_Group27.Data;
using GBC_Travel_Group27.Models;
using Microsoft.AspNetCore.Mvc;

namespace GBC_Travel_Group27.Controllers
{
    public class ListingController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ListingController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Flights()
        {
            List<Flight> flights = _context.Flights.ToList();
            return View(flights);
        }

        public IActionResult Hotels()
        {
            List<Hotel> hotels = _context.Hotels.ToList();
            return View(hotels);
        }

        public IActionResult CarRentals()
        {
            List<CarRental> carRentals = _context.CarRentals.ToList();
            return View(carRentals);
        }
    }
}
