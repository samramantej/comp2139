﻿using Microsoft.AspNetCore.Mvc;
using GBC_Travel_Group27.Data;
using GBC_Travel_Group27.Models;
using System.Collections.Generic;
using System.Linq;

namespace GBC_Travel_Group27.Controllers
{
    public class SearchController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SearchController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult Flights(SearchCriteria criteria)
        {
            
            List<Flight> searchResults = _context.Flights
                .Where(f => f.DepartureCity == criteria.Origin && f.ArrivalCity == criteria.Destination)
                .ToList();
            return View("FlightSearchResults", searchResults);
        }

        [HttpPost]
        public IActionResult Hotels(SearchCriteria criteria)
        {
            
            List<Hotel> searchResults = _context.Hotels
                .Where(h => h.Location == criteria.Location && h.Rating >= criteria.MinRating)
                .ToList();
            return View("HotelSearchResults", searchResults);
        }

        [HttpPost]
        public IActionResult CarRentals(SearchCriteria criteria)
        {
            
            List<CarRental> searchResults = _context.CarRentals
                .Where(c => c.Location == criteria.Location && c.PricePerDay <= criteria.MaxPrice)
                .ToList();
            return View("CarRentalSearchResults", searchResults);
        }
    }
}

