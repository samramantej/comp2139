﻿namespace GBC_Travel_Group27.Models
{
    public class CarRental
    {
        public int Id { get; set; }
        public string CompanyName { get; set; }
        public string Location { get; set; }
        public decimal DailyRate { get; set; }
        public decimal PricePerDay { get; set; }
    }
}
