﻿namespace GBC_Travel_Group27.Models
{
    public class Booking
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public int FlightId { get; set; }
        public int HotelId { get; set; }
        public int CarRentalId { get; set; }
        public DateTime BookingDate { get; set; }
    }

}
