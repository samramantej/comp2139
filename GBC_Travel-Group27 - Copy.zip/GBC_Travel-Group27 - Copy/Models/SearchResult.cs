﻿namespace GBC_Travel_Group27.Models
{
    public class SearchCriteria
    {
        public string Origin { get; set; }
        public string Destination { get; set; }
        public string Location { get; set; }
        public int MinRating { get; set; }
        public decimal MaxPrice { get; set; }
        
    }
}

