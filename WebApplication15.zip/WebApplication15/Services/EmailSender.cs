﻿namespace WebApplication15.Services
{
    public class EmailSender : IEmailSender
    {
    }
}
