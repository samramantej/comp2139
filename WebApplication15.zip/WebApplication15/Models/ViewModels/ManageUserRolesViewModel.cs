﻿namespace WebApplication15.Models.ViewModels
{
    public class ManageUserRolesViewModel
    {

        public string RolesId { get; set; }
        public string RoleName { get; set; }
        public bool Selected { get; set; }

    }
}
