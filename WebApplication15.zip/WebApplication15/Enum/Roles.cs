﻿namespace WebApplication15.Enum
{
    public enum Roles
    {
        SuperAdmin,
        Admin,
        Moderator,
        Basic

    }
}
